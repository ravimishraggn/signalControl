﻿using Common;
using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Configuration
{
    public class ValidityConfiguration
    {
        public void Add(RuleData data)
        {
            Repository r = new Repository();
            r.Add(data);
        }
    }
}
