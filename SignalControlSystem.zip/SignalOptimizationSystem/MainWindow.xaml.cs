﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SignalOptimizationSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LoadData ldWin = new LoadData();
            ldWin.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Configuration confWin = new Configuration();
            confWin.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Model m = new Model();
            var result = m.GetVoilatedData();
            ProcessData pdataWin = new ProcessData();
            StackPanel panel = new StackPanel();
            Label head = new Label();
            head.Content = "List of Voilated Signal";
            panel.Children.Add(head);
            foreach(var r in result.Select(r=>r.Signal).Distinct())
            {
                Label signal = new Label();
                signal.Content = r;
                panel.Children.Add(signal);
            }
            pdataWin.Content = panel;
            pdataWin.Show();
        }
    }
}
