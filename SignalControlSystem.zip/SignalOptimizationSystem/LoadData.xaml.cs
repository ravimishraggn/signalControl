﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Configuration;
using Common;
using DataLayer;

namespace SignalOptimizationSystem
{
    /// <summary>
    /// Interaction logic for LoadData.xaml
    /// </summary>
    public partial class LoadData : Window
    {
        public LoadData()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FileDialog fileDialog = new OpenFileDialog();
            fileDialog.ShowDialog();
            txtInput.Text = fileDialog.FileName;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var filePath = txtInput.Text;
            string jsonString = File.ReadAllText(filePath);
            //var s = new System.Web.Script.Serialization.JavaScriptSerializer();
            //JavaScriptSerializer jss = new JavaScriptSerializer();
            //var data = jss.Deserialize<SignalData>(filePath);

            var data = Newtonsoft.Json.JsonConvert.DeserializeObject<List<SignalData>>(jsonString).ToList();
            Repository rep = new Repository();
            rep.Add(data);

            var result = MessageBox.Show("message loaded successfully");
            if(result == MessageBoxResult.OK)
            {
                this.Close();
            }
        }
    }
}
