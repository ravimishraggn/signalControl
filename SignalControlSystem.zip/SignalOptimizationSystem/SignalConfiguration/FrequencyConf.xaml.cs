﻿using Common;
using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SignalOptimizationSystem.SignalConfiguration
{
    /// <summary>
    /// Interaction logic for FrequencyConf.xaml
    /// </summary>
    public partial class FrequencyConf : Window
    {
        public FrequencyConf()
        {
            InitializeComponent();
            Repository rep = new Repository();
            var signals = rep.GetSignalData().Where(s=>s.value_type=="String").Select(s=>s.Signal);
            foreach (var s in signals)
            {
                this.Signal.Items.Add(s);
            }

            var frequencies = rep.GetSignalData().Where(s => s.value_type == "String").Select(s => s.Value).Distinct();
            foreach (var s in frequencies)
            {
                this.Value.Items.Add(s);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            RuleData r = new RuleData();
            r.Signal = Signal.SelectedItem.ToString();
            r.Operation = Operation.SelectedItem.ToString();
            r.Value = Value.SelectedItem.ToString();
            r.Rule_Type = "Frequency";
            Repository rep = new Repository();
            rep.Add(r);

            MessageBox.Show("Rule Added");
        }
    }
}
