﻿using Common;
using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SignalOptimizationSystem.SignalConfiguration
{
    /// <summary>
    /// Interaction logic for ValueConf.xaml
    /// </summary>
    public partial class ValueConf : Window
    {
        public ValueConf()
        {
            InitializeComponent();
            Repository rep = new Repository();
            var signals = rep.GetSignalData().Where(s => s.value_type == "Integer").Select(s => s.Signal);
            foreach (var s in signals)
            {
                this.Signal.Items.Add(s);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            RuleData r = new RuleData();
            r.Signal = Signal.SelectedItem.ToString();
            r.Operation = Operation.SelectedItem.ToString();
            r.Value = Value.Text.ToString();
            r.Rule_Type = "Value";
            Repository rep = new Repository();
            rep.Add(r);

            MessageBox.Show("Rule Added Successfully");
        }
    }
}
