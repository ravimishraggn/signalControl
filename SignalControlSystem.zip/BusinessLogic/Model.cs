﻿using Common;
using DataLayer;
using RuleEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class Model
    {
        public List<SignalData> GetVoilatedData()
        {
            Repository r = new Repository();
            var signalData = r.GetSignalData();
            var ruleData = r.GetRuleData();

            var rulesNeedToExecute = GetRules(ruleData);

            List<SignalData> voilatedData = new List<SignalData>();
            foreach(var rule in rulesNeedToExecute)
            {
                var data = rule.Execute(signalData, ruleData);
                voilatedData.AddRange(data);
            }

            return voilatedData;
        }

        private List<IRule> GetRules(List<RuleData> ruleData)
        {
            List<IRule> rules = new List<IRule>();
            var rulesTypes = ruleData.Select(r => r.Rule_Type).Distinct();
            foreach(var r in rulesTypes)
            {
                rules.Add(GetRule(r));
            }
            return rules;
        }

        private IRule GetRule(string type)
        {
            IRule rule;
            if(type == "Validity")
            {
                rule = new ValidityRule();
            }
            else if (type == "Frequency")
            {
                rule = new FrequencyRule();
            }
            else if (type == "Value")
            {
                rule = new ValueRule();
            }
            else
            {
                rule = null;
            }
            return rule;
        }
    }
}
