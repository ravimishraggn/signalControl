﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine
{
    public class ValidityRule : IRule
    {
        public List<Common.SignalData> Execute(List<SignalData> data, List<RuleData> ruleData)
        {
            var filteredSignalData = data.Where(r => r.value_type == "Datetime");
            var filteredRuleData = ruleData.Where(r => r.Rule_Type == "Validity");
            var voilatedData = new List<SignalData>();
            foreach (var rule in filteredRuleData)
            {
                if (rule.Operation.Contains("Greater"))
                {
                    GreaterFilter filter = new GreaterFilter();
                    voilatedData = filter.GetResult(filteredSignalData, rule, "Validity").ToList();
                }
                if (rule.Operation.Contains("Less"))
                {
                    LesserFilter filter = new LesserFilter();
                    voilatedData = filter.GetResult(filteredSignalData, rule, "Validity").ToList();
                }
                if (rule.Operation.Contains("Equal"))
                {
                    EqualFilter filter = new EqualFilter();
                    voilatedData = filter.GetResult(filteredSignalData, rule, "Validity").ToList();
                }

                filteredSignalData = filteredSignalData.Where(s => !voilatedData.Select(v => v.Signal).Contains(s.Signal));
            }

            return voilatedData.ToList();
        }
    }
}
