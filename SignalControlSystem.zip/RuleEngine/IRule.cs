﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine
{
    public interface IRule
    {
        List<Common.SignalData> Execute(List<SignalData> data, List<RuleData> ruleData);
    }
}
