﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine
{
    public class FrequencyRule :IRule
    {
        public List<Common.SignalData> Execute(List<SignalData> data, List<RuleData> ruleData)
        {
            var filteredSignalData = data.Where(r=>r.value_type=="String");
            var filteredRuleData = ruleData.Where(r => r.Rule_Type == "Frequency");
            var voilatedData = new List<SignalData>();
            foreach(var rule in filteredRuleData)
            {
                if(rule.Operation.Contains( "NotEqual"))
                {
                    EqualFilter filter = new EqualFilter();
                    voilatedData = filter.GetResult(filteredSignalData, rule, "Frequency").ToList();
                }
                else if (rule.Operation.Contains("Equal"))
                {
                    NotEqualFilter filter = new NotEqualFilter();
                    voilatedData = filter.GetResult(filteredSignalData, rule, "Frequency").ToList();
                }

                filteredSignalData = filteredSignalData.Where(s => !voilatedData.Select(v => v.Signal).Contains(s.Signal));
            }

            return voilatedData.ToList();
        }
    }
}
