﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuleEngine
{
    class NotEqualFilter
    {
        public IEnumerable<Common.SignalData> GetResult(IEnumerable<Common.SignalData> filteredSignalData, RuleData rule, string filterType)
        {
            if (filterType == "Value")
            {
                return filteredSignalData.Where(d => d.Signal == rule.Signal && Convert.ToInt16(d.Value) <= Convert.ToInt16(rule.Value));
            }
            if (filterType == "Frequency")
            {
                return filteredSignalData.Where(d => d.Signal == rule.Signal && d.Value != rule.Value);
            }
            if (filterType == "Validity")
            {
                return filteredSignalData.Where(d => d.Signal == rule.Signal && Convert.ToDateTime(d.Value) <= Convert.ToDateTime(rule.Value));
            }

            return null;
        }
    }
}
