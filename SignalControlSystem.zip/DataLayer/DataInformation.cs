﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class DataInformation
    {
        public static List<SignalData> DataInfo {get;set;}
        public static List<RuleData> RuleInfo { get; set; }

        static DataInformation()
        {
            DataInfo = new List<SignalData>();
            RuleInfo = new List<RuleData>();
        }
    }
}
