﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class Repository
    {
        public void Add(List<SignalData> data)
        {
            DataInformation.DataInfo = data;
        }

        public void Add(RuleData data)
        {
            if (DataInformation.RuleInfo ==null)
            {
                DataInformation.RuleInfo = new List<RuleData>();
            }
            DataInformation.RuleInfo.Add(data);

            
        }

        public List<SignalData> GetSignalData()
        {
            return DataInformation.DataInfo ;
        }

        public List<RuleData> GetRuleData()
        {
            return DataInformation.RuleInfo;
        }
    }
}
