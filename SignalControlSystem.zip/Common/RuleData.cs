﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class RuleData
    {
        public string Signal { get; set; }
        public string Operation { get; set; }
        public string Value { get; set; }
        public string Rule_Type { get; set; }

    }
}
