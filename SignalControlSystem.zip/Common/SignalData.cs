﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class SignalData
    {
        public string Signal { get; set; }
        public string Value { get; set; }
        public string value_type { get; set; }
    }
}
